

TOKENIZER_PATH="Qwen3-32B_Qwen_wothink"
OUTPUT_DIR_PATH="data_test"
python scripts/androidlab_parquet_instruct.py --input_path "task/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}



TOKENIZER_PATH="Qwen2.5-7B-Instruct_Qwen"
OUTPUT_DIR_PATH="data_test_qwen_inst"
python scripts/androidlab_parquet_instruct.py --input_path "task/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}



TOKENIZER_PATH="Meta-Llama-3.1-8B-Instruct_meta-llama"
OUTPUT_DIR_PATH="data_test_llama3.1_inst"
python scripts/androidlab_parquet_instruct.py --input_path "task/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
