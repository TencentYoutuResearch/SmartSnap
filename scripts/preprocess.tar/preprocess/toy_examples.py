import json


toy_examples_1 = [
    {
        "role": "user",
        "content": "## Task Instruction:\nSet an alarm for 9:00 a.m. on Monday"
    },
    {
        "role": "assistant",
        "content": "I need to get the current XML to understand the current screen.",
        "tool_calls":[
            {
                "id": "0",
                "type": "function",
                "function": {
                    "name": "get_current_xml",
                    "arguments": {}
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "Now I can open the Clock app.",
        "tool_calls":[
            {
                "id": "1",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 863,
                        "y1": 390,
                        "x2": 1021,
                        "y2": 672
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "In the alarm page, I should tap the \"Add Alarm\" button to add a new alarm.",
        "tool_calls":[
            {
                "id": "2",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 408,
                        "y1": 1626,
                        "x2": 672,
                        "y2": 1890
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "I can set the alarm now. Firstly, I should set the alarm to 9 o'clock.",
        "tool_calls":[
            {
                "id": "3",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 200,
                        "y1": 1170,
                        "x2": 332,
                        "y2": 1302
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "Then I need to change the clock period toggle to \"AM\".",
        "tool_calls":[
            {
                "id": "4",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 782,
                        "y1": 543,
                        "x2": 925,
                        "y2": 807
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "The alarm is now set, tap \"OK\" to confirm.",
        "tool_calls":[
            {
                "id": "5",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 793,
                        "y1": 1660,
                        "x2": 969,
                        "y2": 1792
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "Now, this alarm will only go off tomorrow. I need to change it to go off once every Monday.",
        "tool_calls":[
            {
                "id": "6",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 209,
                        "y1": 694,
                        "x2": 341,
                        "y2": 826
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "The alarm has been set to go off once every Monday. Now, I'm going to recap the actions and pick the evidences. Based on the \"Creative Verification\" principle, the evidence will be more clear if I go back to the alarm list page. So I will tap \"alarms\" to navigate to the alarm list page.",
        "tool_calls":[
            {
                "id": "7",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 300,
                        "y1": 600,
                        "x2": 350,
                        "y2": 700
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "Now I can see the alarm I just set. I will use this as the evidence for the successful operation. Task is finished.",
        "tool_calls":[
            {
                "id": "8",
                "type": "function",
                "function": {
                    "name": "submit",
                    "arguments": {
                        "message": "The alarm has been set to go off at 9:00 a.m. once every Monday",
                        "evidences": [
                            7
                        ]
                    }
                }
            }
        ]
    }
]


toy_examples_2 = [
    {
        "role": "user",
        "content": "## Task Instruction:\nMove the top email in your inbox to the trash bin."
    },
    {
        "role": "assistant",
        "content": "My task is to move the top email to the trash bin. First, I need to get the current screen layout to identify the target email.",
        "tool_calls":[
            {
                "id": "0",
                "type": "function",
                "function": {
                    "name": "get_current_xml",
                    "arguments": {}
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "I have identified the top email. I will perform a long press on it to enter selection mode and reveal the contextual actions.",
        "tool_calls":[
            {
                "id": "1",
                "type": "function",
                "function": {
                    "name": "long_press",
                    "arguments": {
                        "x1": 84,
                        "y1": 290,
                        "x2": 1000,
                        "y2": 480
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "The email is now selected, and a new action bar has appeared at the top of the screen. I will tap the trash can icon to move the email to the bin.",
        "tool_calls":[
            {
                "id": "2",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 900,
                        "y1": 140,
                        "x2": 1030,
                        "y2": 240
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "The email has been removed from the inbox. As per my core instructions, I need clear evidence of success. To perform **Creative Verification**, I will now navigate to the trash bin to confirm the email is there. I will start by tapping the main menu icon.",
        "tool_calls":[
            {
                "id": "3",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 48,
                        "y1": 138,
                        "x2": 150,
                        "y2": 246
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "The navigation menu is open. I will tap on the \"Trash\" folder to view its contents, which will serve as the definitive proof of my action.",
        "tool_calls":[
            {
                "id": "4",
                "type": "function",
                "function": {
                    "name": "tap",
                    "arguments": {
                        "x1": 50,
                        "y1": 1100,
                        "x2": 800,
                        "y2": 1200
                    }
                }
            }
        ]
    },
    {
        "role": "user",
        "content": "The current screenshot's description is shown: \n** XML **"
    },
    {
        "role": "assistant",
        "content": "I am now on the \"Trash\" screen, and the email I moved is clearly visible. This serves as perfect evidence that the task was completed correctly. I am ready to submit.",
        "tool_calls":[
            {
                "id": "5",
                "type": "function",
                "function": {
                    "name": "submit",
                    "arguments": {
                        "message": "The top email from the inbox has been successfully moved to the trash bin.",
                        "evidences": [
                            4
                        ]
                    }
                }
            }
        ]
    }
]


if __name__ == "__main__":
    print()
    toy_examples_1_str = json.dumps(toy_examples_1, ensure_ascii=False)
    toy_examples_2_str = json.dumps(toy_examples_2, ensure_ascii=False)
    print(toy_examples_1_str)
    print(toy_examples_2_str)

