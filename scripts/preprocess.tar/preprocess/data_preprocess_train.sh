

TOKENIZER_PATH="Qwen3-32B_Qwen_wothink"
OUTPUT_DIR_PATH="data_train"
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}


TOKENIZER_PATH="Qwen2.5-7B-Instruct_Qwen"
OUTPUT_DIR_PATH="data_train_qwen_inst"
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}


TOKENIZER_PATH="Meta-Llama-3.1-8B-Instruct_meta-llama"
OUTPUT_DIR_PATH="data_train_llama3.1_inst"
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/bluecoins.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/calendar.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/cantook.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/clock.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/contacts.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/map.me.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/pi_music_player.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/settings.yaml" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
python scripts/androidlab_parquet_instruct.py --input_path "task_train_verify/" --output_dir ${OUTPUT_DIR_PATH} --tokenizer_path ${TOKENIZER_PATH}
