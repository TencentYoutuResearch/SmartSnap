# Copyright 2024 Bytedance Ltd. and/or its affiliates
# Copyright 2023-2024 SGLang Team
# Copyright 2025 ModelBest Inc. and/or its affiliates
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Preprocess the AndroidLab dataset to parquet format
"""

from toy_examples import toy_examples_1, toy_examples_2
import argparse
import os
import glob
import yaml
from collections import defaultdict
from typing import Dict, List, Any
from transformers import AutoTokenizer
import datasets
from datasets import Dataset
from agent_prompt_instruct import SYSTEM_PROMPT_AGENT, SYSTEM_PROMPT_AGENT_PART
import time


def load_yaml_files(input_path: str) -> Dict[str, Any]:
    """
    Load YAML files from a file or directory
    
    Args:
        input_path: Path to a YAML file or directory containing YAML files
        
    Returns:
        Dictionary mapping app names to their task configurations
    """
    app_configs = {}
    
    if os.path.isfile(input_path) and input_path.endswith('.yaml'):
        # Single YAML file
        with open(input_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            app_name = config.get('APP')
            if app_name:
                app_configs[app_name] = config
    elif os.path.isdir(input_path):
        # Directory containing YAML files
        yaml_files = glob.glob(os.path.join(input_path, "*.yaml"))
        for yaml_file in yaml_files:
            with open(yaml_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                app_name = config.get('APP')
                if app_name:
                    app_configs[app_name] = config
    else:
        raise ValueError(f"Invalid input path: {input_path}")
    
    return app_configs


def process_tasks(app_name: str, app_config: Dict[str, Any], toy_examples_str: str) -> List[Dict[str, Any]]:
    """
    Process tasks for a single app and convert to the required format
    
    Args:
        app_name: Name of the app
        app_config: App configuration containing tasks
        
    Returns:
        List of processed task data
    """
    processed_tasks = []
    package = app_config.get('package', '')
    tasks = app_config.get('tasks', [])

    for idx, task in enumerate(tasks):
        task_id = str(task.get('task_id', f"{app_name}_task_{idx}"))
        task_content = task.get('task', '')
        metric_type = task.get('metric_type', 'operation')
        metric_func = task.get('metric_func', '')
        category = task.get('category', 'general')
        # Create the data structure similar to ref_parquet.py
        data = {
            "data_source": f"androidlab_{app_name}",
            # "data_source": "openai/gsm8k",  # Use a generic source for compatibility
            "agent_name": "mobile_tool_agent", 
            "prompt": [
                {"role": "user", "content": SYSTEM_PROMPT_AGENT_PART + "\n\n" + toy_examples_str + f"\n\n# Task Instruction:\n{task_content}"}
            ],
            "ability": "mobile_operation",
            "reward_model": {"ground_truth": "n/a"},
            "extra_info": {
                "split": "train",  # Default to train split
                "index": idx,
                "need_tools_kwargs": False,
                "mobile_config": {
                    # Basic configuration
                    "avd_name": "Pixel_7_Pro_API_33",
                    "mode": "in_app",
                    "max_steps": 25,
                    "screenshot_timeout": 30,
                    "xml_timeout": 30,
                    "debug": False,  # Disabled for training
                    "verbose": False,
                    "version": None,
                    "is_relative_bbox": False,
                    # Task-specific configuration
                    "app_name": app_name,
                }, 
                "task_config": {
                    "task_id": task_id,
                    "task_instruction": task_content,
                    "app": app_name,
                    "package": package,
                    "category": category,
                    "metric_type": metric_type,
                    "metric_func": metric_func,
                }
            },
        }
        processed_tasks.append(data)
    
    return processed_tasks


def main():
    parser = argparse.ArgumentParser(description="Convert AndroidLab YAML configs to parquet format")
    parser.add_argument(
        "--input_path", 
        required=True,
        help="Path to YAML file or directory containing YAML files"
    )
    parser.add_argument(
        "--tokenizer_path", 
        default="/cfs_turbo/yuleiqin/models/Qwen3-8B_Qwen_nothink",
        help="Path to tokenizer that wrapps the entire conversation"
    )
    parser.add_argument(
        "--output_dir", 
        default="./androidlab_data",
        help="Output directory for parquet files"
    )
    parser.add_argument(
        "--hdfs_dir", 
        default=None,
        help="HDFS directory for storing parquet files"
    )

    
    args = parser.parse_args()
    assert(os.path.exists(args.tokenizer_path))
    print(f">>>>> loading {args.tokenizer_path=}")
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer_path)
    # Create output directory if it doesn't exist
    prompt_toy_examples1 = tokenizer.apply_chat_template(toy_examples_1, add_generation_prompt=False, tokenize=False)
    prompt_toy_examples2 = tokenizer.apply_chat_template(toy_examples_2, add_generation_prompt=False, tokenize=False)
    prompt_toy_str = "# Toy example 1\n" + prompt_toy_examples1 + "\n---\n# Toy example 2\n" + prompt_toy_examples2 + "\n---\n"
    print(f">>>>> converted toy string {prompt_toy_str=}")
    time.sleep(5)
    os.makedirs(args.output_dir, exist_ok=True)
    # Load YAML configurations
    print(f"Loading YAML files from: {args.input_path}")
    app_configs = load_yaml_files(args.input_path)
    print(f"Found {len(app_configs)} apps: {list(app_configs.keys())}")
    
    # Store all processed tasks for combined dataset
    all_processed_tasks = []
    
    # Process each app separately
    for app_name, app_config in app_configs.items():
        print(f"\nProcessing app: {app_name}")
        
        # Process tasks for this app
        processed_tasks = process_tasks(app_name, app_config, toy_examples_str=prompt_toy_str)
        print(f"Processed {len(processed_tasks)} tasks for {app_name}")
        
        if not processed_tasks:
            print(f"No tasks found for {app_name}, skipping...")
            continue
        
        # Add to all tasks list
        all_processed_tasks.extend(processed_tasks)
        
        # Create dataset from processed tasks
        dataset = Dataset.from_list(processed_tasks)
        
        # Save to parquet file
        output_file = os.path.join(args.output_dir, f"{app_name}.parquet").replace(" ", "_")
        dataset.to_parquet(output_file)
        print(f"Saved {app_name} dataset to: {output_file}")
    
    # Create combined dataset with all apps
    if all_processed_tasks:
        print(f"\nCreating combined dataset with {len(all_processed_tasks)} total tasks")
        combined_dataset = Dataset.from_list(all_processed_tasks)
        combined_output_file = os.path.join(args.output_dir, "all_apps_combined.parquet")
        combined_dataset.to_parquet(combined_output_file)
        print(f"Saved combined dataset to: {combined_output_file}")
    else:
        print("\nNo tasks found across all apps, skipping combined dataset creation")
    
    # Copy to HDFS if specified
    if args.hdfs_dir is not None:
        try:
            from verl.utils.hdfs_io import copy, makedirs
            print(f"\nCopying data to HDFS: {args.hdfs_dir}")
            makedirs(args.hdfs_dir)
            copy(src=args.output_dir, dst=args.hdfs_dir)
            print("Successfully copied to HDFS")
        except ImportError:
            print("HDFS utilities not available, skipping HDFS copy")
        except Exception as e:
            print(f"Error copying to HDFS: {e}")
    
    print(f"\nConversion completed! Output directory: {args.output_dir}")
    if all_processed_tasks:
        print(f"Individual app files: {len(app_configs)} files")
        print(f"Combined file: all_apps_combined.parquet ({len(all_processed_tasks)} tasks)")


if __name__ == "__main__":
    main()
